// envia.ck  -  manda un numero por OSC, uno por segundo

"255.255.255.255" => string DESTINO;   // difusion: llega a todos los de la red
9000 => int PUERTO;

OscOut salida;
salida.dest(DESTINO, PUERTO);

0.0 => float n;

while (true)
{
    salida.start("/numero");   // la direccion OSC
    n => salida.add;           // el dato
    salida.send();             // y va

    <<< "envie", n >>>;

    1.0 +=> n;
    1::second => now;
}
