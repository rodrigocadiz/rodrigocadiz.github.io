// recibe-sinusoide.ck  -  escucha /frecuencia y se la pone a un seno

SinOsc s => dac;      // el seno queda sonando fijo desde el principio
0.2  => s.gain;
220.0 => s.freq;

9000 => int PUERTO;

OscIn entrada;
OscMsg msg;
PUERTO => entrada.port;
entrada.listenAll();

<<< "escuchando en el puerto", PUERTO >>>;

while (true)
{
    entrada => now;                        // espera aqui hasta que llegue algo
    while (entrada.recv(msg))
    {
        if (msg.address == "/frecuencia")
        {
            msg.getFloat(0) => float f;    // saca el numero del mensaje
            f => s.freq;                   // y aqui pasa la magia
            <<< "frecuencia ->", f >>>;
        }
    }
}
