// envia-frecuencia.ck  -  manda una frecuencia por OSC, dos veces por segundo

"255.255.255.255" => string DESTINO;   // difusion: llega a todos los de la red
9000 => int PUERTO;

OscOut salida;
salida.dest(DESTINO, PUERTO);

// una escala, para que suene a algo
[220.0, 247.0, 262.0, 294.0, 330.0, 349.0, 392.0, 440.0] @=> float escala[];

while (true)
{
    escala[Math.random2(0, escala.size() - 1)] => float f;

    salida.start("/frecuencia");   // la direccion OSC
    f => salida.add;               // el numero
    salida.send();                 // y va

    <<< "envie", f, "Hz" >>>;

    500::ms => now;
}
