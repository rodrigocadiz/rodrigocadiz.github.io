// recibe.ck  -  escucha /numero y lo imprime

9000 => int PUERTO;

OscIn entrada;
OscMsg msg;
PUERTO => entrada.port;
entrada.listenAll();

<<< "escuchando en el puerto", PUERTO >>>;

while (true)
{
    entrada => now;                  // espera aqui hasta que llegue algo
    while (entrada.recv(msg))
        <<< "llego:", msg.getFloat(0) >>>;
}
